from django.contrib import admin
from .models import userreg
from .models import logintable
from .models import clientprofile
from .models import clienttable
from .models import bookingtable


admin.site.register(clientprofile)
admin.site.register(userreg)
admin.site.register(logintable)
admin.site.register(clienttable)
admin.site.register(bookingtable)
# Register your models here.
