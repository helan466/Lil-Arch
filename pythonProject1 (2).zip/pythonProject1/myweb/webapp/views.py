from django.shortcuts import render
from .models import userreg
from .models import logintable
from .models import clientprofile
from .models import clienttable
from .models import bookingtable
from datetime import datetime


def home(request):
    return render(request,'home.html')
def reg(request):
    return render(request,'register.html')
def reg1(request):
    a = request.POST['fname']
    b = request.POST['lname']
    c = request.POST['add']
    e = request.POST['mail']
    f= request.POST['phn']
    g=request.POST['pass']
    data=userreg(First_name=a,Last_name=b,user_address=c,Email=e,phone_number=f,password=g)
    data.save()

    data1= logintable(Email=e,password=g,status=1)
    data1.save()
    return render(request, 'home.html')
def creg(request):
    return render(request,'clientreg.html')
def creg1(request):
    h=request.FILES['imag']
    i=request.POST['cname']
    s = request.POST['CEmail']
    t = request.POST['cepass']
    m=request.POST['org']
    j=request.POST['dec']
    data3=clienttable(client_image=h,client_name=i,CEmail=s,password=t, organization=m,description=j,status=2)
    data3.save()
    data1= logintable(Email=s, password=t, status=2)
    data1.save()
    return render(request,'home.html')

def clientpro(request):
    return render(request,'clientprofile.html')
def pro(request):
    return render(request,'product.html')
def productpro(request):
    o=request.FILES['ima']
    m = request.POST['org']
    p=request.POST['cname']
    s=request.POST['Cmail']
    k=request.POST['cabout']
    l=request.FILES['pic']
    l1=request.FILES['pic1']
    l2=request.FILES['pic2']
    l3=request.FILES['pic3']
    l4=request.FILES['pic4']
    l5=request.FILES['pic5']
    n=request.POST['portname']
    n1=request.POST['portname1']
    n2=request.POST['portname2']
    n3=request.POST['portname3']
    n4= request.POST['portname4']
    n5=request.POST['portname5']
    q=request.POST['dec']
    q1 = request.POST['dec1']
    q2 = request.POST['dec2']
    q3 = request.POST['dec3']
    q4 = request.POST['dec4']
    q5 = request.POST['dec5']
    emp_im = request.FILES['pht']
    emp_name = request.POST['empn']
    emp_dec = request.POST['empdec']
    emp_im1 = request.FILES['pht1']
    emp_name1 = request.POST['empn1']
    emp_dec1 = request.POST['empdec1']
    emp_im2 = request.FILES['pht2']
    emp_name2 = request.POST['empn2']
    emp_dec2 = request.POST['empdec3']
    p1 = request.POST['id1']
    p2 = request.POST['id2']
    p3 = request.POST['id3']
    data2 = clientprofile(portfolio_image3=l3,portfolio_image4=l4,portfolio_image5=l5,portfolio_name1=n1,portfolio_name2=n2,portfolio_name3=n3,portfolio_name4=n4,portfolio_name5=n5)
    data2 = clientprofile(client_image=o,client_name=p,Cmail=s,about_client=k,portfolio_image=l,portfolio_image1=l1,portfolio_image2=l2,portfolio_name=n,description=q)
    data2 = clientprofile(description1=q1,description2=q2,description3=q3,description4=q4,description5=q5,organization=m)
    data2 = clientprofile(em_image=emp_im, em_name=emp_name, em_description=emp_dec,em_image1=emp_im1, em_name2=emp_name2, em_description2=emp_dec2,em_image3=emp_im3, em_name3=emp_name3, em_description3=emp_dec3)
    data2=clientprofile(price1=p1,price2=p2,price3=p3)
    data2.save()
    data2.save()
    data2.save()
    data2.save()
    data2.save()

def clientviews(request):

      id=request.POST['id']
      data2 = clientprofile.objects.filter(Cmail=id)

      return render(request,'clientprofile.html',{'data2':data2})


def proviews(request):
    details = bookingtable.objects.filter(status=0)
    return render(request, 'pay.html', {'details': details})
def login(request):
    return render(request,'login.html')
def log(request):
    m = logintable.objects.get(Email=request.POST['mail'],password=request.POST['pass'],)

    if m.status==1:
        request.session['member_id']=m.Email
        data3=clienttable.objects.all()


        return render(request, 'productviews.html', {'data3': data3})
        #return render(request, 'clientprofile.html',{'data2':data2,'data3':data3})

    elif m.status==0:
        request.session['member_id'] = m.id
        data=userreg.objects.all()
        data3=clienttable.objects.all()

        return render(request, 'adviews.html',{'data3': data3,'data': data})

    elif m.status==2:
        request.session['member_id'] = m.id
        details = bookingtable.objects.all()
        data2 = clientprofile.objects.all()
        return render(request,'cbookingview.html',{'data2':data2,'details':details},)
def logout(request):
    del request.session['member_id']
    return render(request,'home.html')



def buydetails(request):
        pr = request.POST['id']
        us= request.session['member_id']
        tm = datetime.now()


        details= bookingtable(product_id=pr, user_id=us, day_time=tm, status=0)
        details.save()
        data2 = clientprofile.objects.all()
        return render(request,'clientprofile.html',{'data2':data2})

def proad(request):
    data3 = clienttable.objects.all()
    data = userreg.objects.all()
    return render(request,'adviews.html',{'data3':data3,'data':data})

def update(request):
        id = request.POST['id']
        bookingtable.objects.filter(id=id).update(status=1)
        details = bookingtable.objects.filter(status=0)
        return render(request, 'pay.html', {'details': details})



# Create your views here.

