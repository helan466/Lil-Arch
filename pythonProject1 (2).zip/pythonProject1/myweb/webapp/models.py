from django.db import models
import datetime
class userreg(models.Model):
    First_name=models.CharField(max_length=30)
    Last_name=models.CharField(max_length=30)
    user_address=models.CharField(max_length=30)
    Email=models.CharField(max_length=30)
    phone_number=models.IntegerField()
    password=models.IntegerField()
class clienttable(models.Model):
    client_image = models.FileField()
    client_name = models.CharField(max_length=30)
    CEmail = models.CharField(max_length=30)
    password = models.IntegerField()
    organization= models.CharField(max_length=50)
    description = models.CharField(max_length=50)
    status=models.IntegerField()
class logintable(models.Model):
    Email=models.CharField(max_length=30)
    password=models.CharField(max_length=50)
    status=models.IntegerField()


class clientprofile(models.Model):
    Cmail = models.CharField( max_length=30)
    organization = models.CharField(max_length=50)
    client_image=models.FileField()
    client_name=models.CharField(max_length=30)
    about_client=models.CharField(max_length=50)

    portfolio_image = models.FileField()
    portfolio_image1 = models.FileField()
    portfolio_image2 = models.FileField()
    portfolio_image3 = models.FileField()
    portfolio_image4 = models.FileField()
    portfolio_image5= models.FileField()
    portfolio_name=models.CharField(max_length=30)
    portfolio_name1=models.CharField(max_length=30)
    portfolio_name2=models.CharField(max_length=30)
    portfolio_name3=models.CharField(max_length=30)
    portfolio_name4=models.CharField(max_length=30)
    portfolio_name5=models.CharField(max_length=30)
    description=models.CharField(max_length=100)
    description1 = models.CharField(max_length=100)
    description2 = models.CharField(max_length=100)
    description3 = models.CharField(max_length=100)
    description4 = models.CharField(max_length=100)
    description5 = models.CharField(max_length=100)
    em_image=models.FileField()
    em_name=models.CharField(max_length=30)
    em_description=models.CharField(max_length=50)
    price1=models.IntegerField()
    price2 = models.IntegerField()
    price3 = models.IntegerField()
class bookingtable(models.Model):
    product_id = models.CharField(max_length=30)
    user_id = models.CharField(max_length=30)
    day_time = models.CharField(max_length=30)
    status=models.IntegerField()


# Create your models here.
